<table class="table table-striped">
    <tr>
        <th>ID</th>
        <td>{{ $software->id }}</td>
    </tr>
    <tr>
        <th>Parent ID</th>
        <td>{{ $software->software }}</td>
    </tr>
</table>

