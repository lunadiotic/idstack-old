<table class="table table-striped">
    <tr>
        <th>ID</th>
        <td>{{ $level->id }}</td>
    </tr>
    <tr>
        <th>Parent ID</th>
        <td>{{ $level->level }}</td>
    </tr>
</table>

