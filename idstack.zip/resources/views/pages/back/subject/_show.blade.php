<table class="table table-striped">
    <tr>
        <th>ID</th>
        <td>{{ $subject->id }}</td>
    </tr>
    <tr>
        <th>Parent ID</th>
        <td>{{ $subject->parent_id }}</td>
    </tr>
    <tr>
        <th>Slug</th>
        <td>{{ $subject->slug }}</td>
    </tr>
    <tr>
        <th>Subject</th>
        <td>{{ $subject->subject }}</td>
    </tr>
</table>

