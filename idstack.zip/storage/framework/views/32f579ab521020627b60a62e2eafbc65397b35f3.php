<?php $__env->startSection('styles'); ?>
    <!-- DataTables -->
    <link href="<?php echo e(asset('assets/back/plugins/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/back/plugins/datatables/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- Responsive datatable examples -->
    <link href="<?php echo e(asset('assets/back/plugins/datatables/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <style>
        .modal-lg {
            width: 750px;
            margin: auto;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <?php echo $__env->make('layouts.back.partials._bread', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">
        <div class="col-12">
            <div class="card-box table-responsive">
                <h4 class="m-t-0 header-title"><b>Default Example</b></h4>
                <p class="text-muted font-13 m-b-30">
                    <a href="<?php echo e(route('admin.subject.create')); ?>" class="btn btn-primary pull-right show-modal" style="margin-top: -29px;" title="Create Data">Create Data</a>
                </p>

                <table id="datatable" class="table table-bordered">
                    <thead>
                        <tr>
                            <th width="30">ID</th>
                            <th>Parent_ID</th>
                            <th>Slug</th>
                            <th>Subject</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
    </div> <!-- end row -->
    <?php echo $__env->make('pages.back.user.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('pages.back.user.modalconfirm', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div> <!-- container -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <!-- Required datatable js -->
    <script src="<?php echo e(asset('assets/back/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/back/plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/back/plugins/datatables/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/back/plugins/datatables/responsive.bootstrap4.min.js')); ?>"></script>

    <script src="<?php echo e(asset('vendor/laravel-filemanager/js/lfm.js')); ?>"></script>

    <script type="text/javascript">
        $('#datatable').DataTable({
            processing: true,
            serverSide: true,
            ajax: "<?php echo e(route('data.subject')); ?>",
            columns: [
                {data: 'id', name: 'id'},
                {data: 'parent_id', name: 'parent_id'},
                {data: 'slug', name: 'slug'},
                {data: 'subject', name: 'subject'},
                {data: 'action', name: 'action', orderable: false, searchable: false}
            ]
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.back.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>