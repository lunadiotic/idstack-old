<?php $__env->startSection('content'); ?>
    <div class="main-wrapper scrollspy-container">
			<!-- start hero-header -->
			<div class="hero overlay-3" style="background-image:url('<?php echo e(url('/')); ?>/assets/front/images/hero-header/01.png');">
			
				<div class="container">
				
					<div class="row">
					
						<div class="main-search-wrapper">
					
							<h2 class="text-center">What course will you like to learn?</h2>
							<p class="lead text-center">Cari seri tutorial yang kamu butuhkan di sini.</p>

							<form action="<?php echo e(route('series.search')); ?>" method="GET">
								<div class="input-group">
									<input type="text" name="q" class="form-control placeholder-type-writter">
									<span class="input-group-btn">
										<button class="btn btn-primary" type="button"><i class="ion-ios-search-strong"></i></button>
									</span>
								</div><!-- /input-group -->
							</form>
						
							<div class="featured-sm-wrapper">
								
								<div class="GridLex-gap-30">
					
									<div class="GridLex-grid-noGutter-equalHeight GridLex-grid-center">
									
										<div class="GridLex-col-4_sm-4_xs-8_xss-12">
										
											<div class="featured-sm-item clearfix">
												
												<div class="icon">
													<i class="ion-clipboard"></i>
												</div>
												
												<div class="content">
													Lebih dari <?php echo e(number_format($courses->count())); ?> seri yang tersedia
												</div>
												
											</div>
											
										</div>
										
										<div class="GridLex-col-4_sm-4_xs-8_xss-12">
										
											<div class="featured-sm-item clearfix">
											
												<div class="icon">
													<i class="ion-person-stalker"></i>
												</div>
												
												<div class="content">
													Terdapat <?php echo e(App\Models\User::count()); ?> peserta yang bergabung
												</div>
												
											</div>
											
										</div>
										
										<div class="GridLex-col-4_sm-4_xs-8_xss-12">
										
											<div class="featured-sm-item clearfix">
											
												<div class="icon">
													<i class="ion-ipad"></i>
												</div>
												
												<div class="content">
													Bebas belajar di manapun, kapanpun.
												</div>
												
											</div>
											
										</div>
										
									</div>
									
								</div>

							</div>
							
						</div>
						
						
					</div>
					
				</div>
				
			</div>
			<!-- end hero-header -->
	
			<!-- start Top Offer -->
			<section class="section bg-light">
			
				<div class="container">
				
					<div class="row">
					
						<div class="col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2">
						
							<div class="section-title">
								<h2 class="text-center">Seri Terbaru</h2>
								<p>Pengalaman baru yang bisa kamu pelajari melalui karya-karya terbaru dari para ahlinya. Temukan selanjutnya di sini:</p>
							</div>
						</div>
					
					</div>
					
					<div class="course-item-wrapper gap-20">
					
						<div class="GridLex-grid-noGutter-equalHeight GridLex-grid-center">

                            <?php
                                $courses = $courses->orderBy('id', 'desc')->take(8)->get();
                            ?>

                            <?php if($courses->count()): ?>
                                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="GridLex-col-3_mdd-4_sm-6_xs-6_xss-12">
                                        <div class="course-item">
                                            <a href="<?php echo e(route('series.detail', $course->slug)); ?>">
                                                <div class="course-item-image">
                                                    <img src="<?php echo e($course->image); ?>" alt="Image" class="img-responsive" />
                                                </div>
                                                <div class="course-item-top clearfix">
                                                    <div class="course-item-instructor">
                                                        <div class="image">
                                                            <img src="<?php echo e($course->user->image); ?>" alt="Image" class="img-circle" />
                                                        </div>
                                                        <span><?php echo e(ucwords($course->user->name)); ?> </span>
                                                    </div>
                                                    <div class="course-item-price bg-danger">
                                                        <?php echo e($course->price); ?>

                                                    </div>
                                                </div>
                                                <div class="course-item-content">
                                                    
                                                    <h3 class="text-primary"><?php echo e($course->title); ?></h3>
                                                    <p><?php echo str_limit($course->desc, 100); ?></p>
                                                </div>
                                                <div class="course-item-bottom clearfix">
                                                    <div><i class="fa fa-folder-open-o"></i>
                                                        
														<?php echo e($course->subjects()->first()->subject); ?>

                                                    </div>
                                                    <div><i class="fa fa-pencil-square-o"></i>
                                                        <span class="block"><?php echo e($course->detail->count()); ?> Lessons</span>
                                                    </div>
                                                    <div><i class="fa fa-check-square-o"></i><span class="block"> <?php echo e($course->level->level); ?></span></div>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

						</div>
					
					</div>

				</div>
				
			</section>
			<!-- end Top Offer -->

			<div class="overflow-hidden">
			
				<div class="GridLex-grid-noGutter-equalHeight">
				
					<div class="GridLex-col-6_sm-12_xs-12 bg-img" style="background-image:url('<?php echo e(url('/')); ?>/assets/front/images/hero-header-slider/02.jpg'); background-position: top right">
					
						<div class="promo-box-03 overlay-danger">
						
							<div class="promo-box-03-inner">
							
								<h2 class="mb-25 text-white">Bergabunglah dengan peserta lainnya</h2>
								<p>Seru! Ikuti belajar bersama mereka dan temukan sahabat baru dalam hobi yang sama. </p>
								
								<a href="<?php echo e(route('register')); ?>" class="btn btn-primary">Gabung Sekarang</a>
								
							</div>
							
						</div>
						
					</div>
					
					<div class="GridLex-col-6_sm-12_xs-12 bg-img" style="background-image:url('<?php echo e(url('/')); ?>/assets/front/images/teacher-bg.jpg'); background-position: top right">
					
						<div class="promo-box-03 overlay-primary">
							
							<div class="promo-box-03-inner">
							
								<h2 class="mb-25 text-white">Ingin berbagi pengalaman dengan mereka ?</h2>
								<p>Kami beri kesempatan terbuka untuk para ahli dapat berkontribusi melalui media belajar bersama ini.</p>
								
								<a href="#" class="btn btn-danger">Ikuti Petunjuk</a>
							
							</div>
							
						</div>
						
					</div>
					
				</div>
				
			</div>

			
			
		</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>