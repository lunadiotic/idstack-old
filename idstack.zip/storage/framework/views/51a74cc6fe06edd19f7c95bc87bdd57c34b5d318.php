<table class="table table-striped">
    <tr>
        <th>ID</th>
        <td><?php echo e($subject->id); ?></td>
    </tr>
    <tr>
        <th>Parent ID</th>
        <td><?php echo e($subject->parent_id); ?></td>
    </tr>
    <tr>
        <th>Slug</th>
        <td><?php echo e($subject->slug); ?></td>
    </tr>
    <tr>
        <th>Subject</th>
        <td><?php echo e($subject->subject); ?></td>
    </tr>
</table>

