<?php $__env->startComponent('mail::message'); ?>
# Aktifkan Akun Anda

Terima kasih telah bergabung <?php echo e($user->name); ?>, agar akun dapat Anda gunakan, mohon aktivasi akun Anda dengan mengklik tombol di bawah ini.

<?php $__env->startComponent('mail::button', ['url' => route('auth.activate', [
                                    'token' => $user->activation_token,
                                    'email' => $user->email
                                ])
                            ]
            ); ?>
    Activate
<?php echo $__env->renderComponent(); ?>

Salam Kami,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
