<table class="table table-striped">
    <tr>
        <th>ID</th>
        <td><?php echo e($course->id); ?></td>
    </tr>
    <tr>
        <th>Instructor</th>
        <td><?php echo e($course->user->name); ?></td>
    </tr>
    <tr>
        <th>Level</th>
        <td><?php echo e($course->level->level); ?></td>
    </tr>
    <tr>
        <th>Title</th>
        <td><?php echo e($course->title); ?></td>
    </tr>
    <tr>
        <th>Description</th>
        <td><?php echo $course->desc; ?></td>
    </tr>
    <tr>
        <th>Price</th>
        <td><?php echo e($course->price); ?></td>
    </tr>
    <tr>
        <th>Subjects</th>
        <td>
            <ul>
                <?php $__currentLoopData = $course->subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($row->subject); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </td>
    </tr>
    <tr>
        <th>Software</th>
        <td>
            <ul>
                <?php $__currentLoopData = $course->software; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($row->software); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </td>
    </tr>
    <tr>
        <th>Featured Image</th>
        <td><img src="<?php echo e($course->image); ?>" id="holder" style="margin-top:15px;max-height:254px;max-width: 152px;"></td>
    </tr>
</table>

