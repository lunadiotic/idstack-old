<?php echo Form::model($detail, [
        'route' => $detail->exists ? ['admin.course.detail.update', $detail->id] : 'admin.course.detail.store',
        'method' => $detail->exists ? 'PUT' : 'POST'
    ]); ?>

    <?php echo Form::hidden('id'); ?>    
    <?php echo Form::hidden('course_id', null, ['id' => 'data_id']); ?>


    <div class="row">
        <div class="col-md-12">
            <div class="form-group">
                <label for="field-3" class="control-label">Title</label>
                <?php echo Form::text('title', null, ['class' => 'form-control', 'id' => 'title', 'autofocus']); ?>

            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="form-group">
                <label for="field-3" class="control-label">Description</label>
                <?php echo Form::textarea('desc', null, ['class' => 'form-control', 'id' => 'desc', 'cols'=>"30", 'rows'=>"10"]); ?>

            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="form-group">
                <label for="" class="control-label">Embed URL</label>
        <?php echo Form::text('iframe', null, ['class' => 'form-control', 'id' => 'iframe',]); ?>

            </div>
        </div>
    </div>
    
<?php echo Form::close(); ?>