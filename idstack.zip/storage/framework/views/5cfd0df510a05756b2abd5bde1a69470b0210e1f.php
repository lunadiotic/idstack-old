<?php $__env->startSection('title'); ?>
    Kumpulan Tutorial Koding
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-wrapper scrollspy-container">
		
        <div class="breadcrumb-wrapper">
        
            <div class="container">
            
                <h1 class="page-title">Daftar Seri</h1>
                
                <div class="row xBread">
                
                    <div class="col-xs-12 col-sm-8">
                        <ol class="breadcrumb">
                            <li><a href="#">Beranda</a></li>
                            <li><a href="#">Seri</a></li>
                            <li class="active">Daftar Seri</li>
                        </ol>
                    </div>
                    
                </div>
                
            </div>

        </div>
    
        <div class="equal-content-sidebar-wrapper">
        
            <div class="equal-content-sidebar-by-gridLex">
            
                <div class="container">
                
                    <div class="GridLex-grid-noGutter-equalHeight">
            
                        <div class="GridLex-col-3_sm-4_xs-12_xss-12">

                            <div class="sidebar-wrapper pt-20-xs pb-0-xs">

                                <aside class="filter-sidebar">
                
                                    <div class="responsive-filter-wrapper">
                                
                                        <button type="button" class="navbar-toggle btn btn-primary collapsed btn-responsive-filter" data-toggle="collapse" data-target="#responsive-filter-box">Search Again &amp; Filter</button>
                                        
                                        <div class="clear"></div>

                                        <form action="<?php echo e(route('series.search')); ?>" method="GET">
                                            <div class="input-group">
                                                <input type="text" name="q" class="form-control placeholder-type-writter">
                                                <span class="input-group-btn">
                                                    <button class="btn btn-primary" type="button"><i class="ion-ios-search-strong"></i></button>
                                                </span>
                                            </div><!-- /input-group -->
                                        </form>

                                        </br>
                                        
                                        <div class="collapse navbar-collapse responsive-filter-box" id="responsive-filter-box">
                                        
                                            <div class="collapse-inner">

                                                <div class="sidebar-header clearfix">
                                                    <h4>Filter Pencarian</h4>
                                                    
                                                </div>
                                                
                                                <div class="sidebar-inner">
                                                
                                                    <div class="row gap-20">
                                                        
                                                        <div class="clear"></div>
                                                    
                                                        <div class="col-xss-12 col-xs-6 col-sm-12">
                                                        
                                                            <div class="sidebar-module clearfix">
                                                    
                                                                <h6 class="sidebar-title">Berdasarkan Pelajaran</h6>
                                                                <div class="sidebar-module-inner">
                                                                    <?php if($subject->count()): ?>
                                                                        <?php $__currentLoopData = $subject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <div class="checkbox-block">
                                                                                <input id="property_type-<?php echo e($row->id); ?>" name="property_type" type="checkbox" class="checkbox"/>
                                                                                <label class="" for="property_type-<?php echo e($row->id); ?>"><?php echo e($row->subject); ?> </label>
                                                                            </div>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php endif; ?>                                                                    
                                                                </div>
                                                            
                                                            </div>
                                                            
                                                        </div>
                                                        
                                                        <div class="col-xss-12 col-xs-6 col-sm-12">
                                                        
                                                            <div class="sidebar-module clearfix">
                                                    
                                                                <h6 class="sidebar-title">Berdasarkan Kategori</h6>
                                                                
                                                                <div class="sidebar-module-inner">
                                                                    <?php if($software->count()): ?>
                                                                        <?php $__currentLoopData = $software; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <div class="checkbox-block">
                                                                                <input id="hotel_facilities-<?php echo e($row->id); ?>" name="hotel_facilities" type="checkbox" class="checkbox"/>
                                                                                <label class="" for="hotel_facilities-<?php echo e($row->id); ?>"><?php echo e($row->software); ?></label>
                                                                            </div>  
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php endif; ?> 
                                                    
                                                                </div>
        
                                                            </div>
                                                            
                                                        </div>
                                                        
                                                        <div class="clear"></div>
                                                        
                                                    </div>
                                                    
                                                </div>
                                                
                                            </div>
                                            
                                        </div>
                                    
                                    </div>
                                
                                </aside>
                                
                            </div>
                            
                        </div>

                        <div class="GridLex-col-9_sm-8_xs-12_xss-12">
                    
                            <div class="content-wrapper pt-20-xs">

                                
                                
                                <div class="course-list-item-wrapper alt">
                            
                                    <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="course-list-item">
                                    
                                            <div class="row gap-25">
                                            
                                                <div class="col-xss-12 col-xs-4 col-sm-4 col-md-4">
                                                
                                                    <div class="image">
                                                        <img src="<?php echo e($course->image); ?>" alt="image" />
                                                    </div>
                                                    
                                                </div>
                                                
                                                <div class="col-xss-12 col-xs-8 col-sm-8 col-md-8">
                                                
                                                    <div class="content">
                                                    
                                                        <h4><a href="<?php echo e(route('series.detail', $course->slug)); ?>"><?php echo e($course->title); ?></a></h4>
                                                        
                                                        <div class="content-inner">
                                                        
                                                            <div class="row gap-20">
                                                            
                                                                <div class="col-xss-7 col-xs-8 col-sm-8 col-md-6">
                                                                    <div class="course-instructor">
                                                                        <div class="image">
                                                                            <img src="<?php echo e($course->user->image); ?>" alt="Image" class="img-circle" />
                                                                        </div>
                                                                        <span><?php echo e($course->user->name); ?></span>
                                                                        
                                                                    </div>
                                                                </div>
                                                                
                                                                <div class="col-xss-5 col-xs-4 col-sm-4 col-md-3">
                                                                    
                                                                </div>
                                                                
                                                                <div class="col-xss-12 col-xs-12 col-sm-12 col-md-3">
                                                                    <div class="price">
                                                                        <?php echo e($course->price); ?>

                                                                    </div>
                                                                </div>
                                                                
                                                            </div>
                                                            
                                                        </div>
                                                        
                                                        <p><?php echo str_limit($course->desc, 100); ?></p>
                                                        
                                                        <ul class="meta-list clearfix">
                                                            <li><i class="fa fa-folder-open-o"></i><span class="block"> <?php echo e($course->subjects()->first()->subject); ?></span></li>
                                                            <li><i class="fa fa-pencil-square-o"></i><span class="block"> <?php echo e($course->detail->count()); ?> Lessons</span></li>
                                                            <li><i class="fa fa-check-square-o"></i><span class="block"> <?php echo e($course->level->level); ?></span></li>
                                                            <li class="btn-box"><a href="<?php echo e(route('series.detail', $course->slug)); ?>" class="btn btn-primary btn-form btn-inverse">details</a></li>
                                                        </ul>
                                                        
                                                    </div>
                                                    
                                                </div>
                                            
                                            </div>
                                        
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>

                                <div class="clear"></div>
                                
                                <div class="pager-wrappper clearfix">
                
                                    <div class="pager-innner">
                                    
                                        <div class="row">
                                                
                                            <div class="col-xs-12 col-sm-12 col-sm-6">
                                                <div class="pagination-text">Showing result <?php echo e($courses->firstItem()); ?> to <?php echo e($courses->lastItem()); ?> from <?php echo e($courses->total()); ?> </div>
                                            </div>
                                            
                                            <div class="col-xs-12 col-sm-12 col-sm-6">
                                                <nav class="pager-right">
                                                    <?php echo e($courses->links()); ?>

                                                </nav>
                                            </div>
                                        
                                        </div>
                                        
                                    </div>
                                    
                                </div>

                            
                            </div>
                        
                        </div>
                        
                    </div>
                    
                </div>
                
            </div>
            
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>